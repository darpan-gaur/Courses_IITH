Make an input file which contains k, m, n , alpha, beta, lambda, mu, all space separated. 

Change the path/name of the input file in code as per your convinience.

Compile :-  g++ labExam-IceCreamParty-Src-CO21BTECH11004.cpp 

Execute :- ./a.out

Output file :- output.txt would be created
Time in output file is printed in microseconds with refrence to start time fetched at staring of program globally.