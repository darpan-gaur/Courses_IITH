#include "types.h"
#include "user.h"
#include "date.h"

// uncomment this to use global array
// int arrGlobal[10000];

int main(int argc, char *argv[])
{   
  // for local array uncomment thie ------------
    // int arrLocal[10000];

    // for (int i = 0; i < 1024; i++)
    // {
    //     arrLocal[i] += i;
    // }
  // -------------------------------------------
  pgtPrint();
  exit();
  return 0;
}