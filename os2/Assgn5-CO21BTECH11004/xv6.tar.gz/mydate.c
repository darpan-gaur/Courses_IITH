#include "types.h"
#include "user.h"
#include "date.h"

int main(int argc, char *argv[])
{
  struct rtcdate r;

  if (date(&r)) {
    printf(2, "date failed\n");
    exit();
  }
  // prints date
  printf(1,"Date (DD-MM-YYYY): %d-%d-%d\n", r.day, r.month, r.year);
  // prints time
  printf(1,"Time (HH:MM:SS) : %d:%d:%d\n", r.hour, r.minute, r.second);

  exit();
}
