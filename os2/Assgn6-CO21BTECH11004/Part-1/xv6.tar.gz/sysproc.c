#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

void print_hex_addr(uint addr) {
  char buf[9]; // buffer to hold the hex string (including null terminator)
  int i;
  
  // convert the address to a hex string with leading zeros
  for (i = 0; i < 8; i++) {
    buf[7-i] = "0123456789abcdef"[addr & 0xf];
    addr >>= 4;
  }
  buf[8] = '\0';
  
  // print the hex string
  cprintf("0x%s", buf);
}

int sys_pgtPrint(void)
{
  struct proc *p = myproc();

  pde_t *pgdir = p->pgdir;
  int i,j,argument,pageTablePage,pageTableEntry;
  pageTablePage = NPDENTRIES;
  pageTableEntry = NPTENTRIES;

  if (argint(0, &argument) < 0){
    cprintf("No argument passed\n");
    return -1;
  }
  // for first level page directory
  for (i=0;i<pageTablePage;i++) {
    if (pgdir[i] & PTE_P) {
      pde_t *pageTable = (pde_t*)P2V(PTE_ADDR(pgdir[i]));

      // for second level page table
      for (j=0;j<pageTableEntry;j++) {
        if ((pageTable[j] & PTE_P) && (pageTable[j] & PTE_U)) {
          // cprintf("Entry number: %d, Virtual Address: 0x%x, Physical Address: 0x%x\n", i*pageTablePage+j, PGADDR(i,j,0), PTE_ADDR(pageTable[j]));
          cprintf("Entry number: %d, Virtual Address: ", i*pageTablePage+j);
          print_hex_addr(PGADDR(i,j,0));
          cprintf(", Physical Address: 0x%x\n", PTE_ADDR(pageTable[j]));
        } 
      }
    }
  }
  
  
  return 0;
}