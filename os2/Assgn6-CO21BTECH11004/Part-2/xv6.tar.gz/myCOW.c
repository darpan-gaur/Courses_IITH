#include "types.h"
#include "stat.h"
#include "user.h"

#define N 3000      // global array size - change to see effect. Try 3000, 5000, 10000
int glob[N];
int main(void)
{
	int pid;
	// pgtPrint();
	pid = fork();
	if (pid == 0)
	{	
		printf(1,"Same code as part 1, child writing on each element of array\n");
		printf(1,"Page table before changing\n");
		pgtPrint();
		for (int i = 1; i < N; i++)
		{
			glob[i] = glob[i - 1];
			if (i % 1000 == 0){
				printf(1,"Page table in the middle of child changing array at idx: %d,\n", i);
				pgtPrint();
			}
		}
		printf(1,"Page table after changing\n");
		pgtPrint();
	}
	else
	{
		wait();
		// pgtPrint();	
	}
	exit();
}
