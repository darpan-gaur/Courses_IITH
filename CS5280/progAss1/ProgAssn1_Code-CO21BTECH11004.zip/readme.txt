Make input file which contains n, m, totTrans, constVal, lambda and numIters as space separated values.

Change the path/name of the input file in code as per your convinience.
Default path/name of input file is "inp-params.txt"

Compile: g++ BOCC-CO21BTECH11004.cpp -o BOCC
Execute: ./BOCC
Ouput: log file "boccLog.txt" will be generated in the same directory.

Compile: g++ FOCC-CTA-CO21BTECH11004.cpp -o FOCC
Execute: ./FOCC
Ouput: log file "foccCTALog.txt" will be generated in the same directory.